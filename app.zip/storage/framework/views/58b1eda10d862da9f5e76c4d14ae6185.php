<main <?php echo e($attributes->class(['layout-content'])); ?>>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<?php /**PATH /var/www/vendor/moonshine/moonshine/src/Providers/../../resources/views/components/layout/content.blade.php ENDPATH**/ ?>