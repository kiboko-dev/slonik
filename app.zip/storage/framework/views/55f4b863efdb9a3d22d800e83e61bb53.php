<div <?php echo e($attributes
        ->class([
            'my-4',
        ])); ?>></div>
<?php /**PATH /var/www/vendor/moonshine/moonshine/src/Providers/../../resources/views/decorations/line-break.blade.php ENDPATH**/ ?>