<button
    <?php echo e($attributes->class(['btn'])
        ->merge(['type' => 'button'])); ?>

>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /var/www/vendor/moonshine/moonshine/src/Providers/../../resources/views/components/form/button.blade.php ENDPATH**/ ?>