<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"
     class="fill-current w-<?php echo e($size ?? 5); ?> h-<?php echo e($size ?? 5); ?> <?php echo e($class ?? ''); ?> <?php echo e(!empty($color) ? "text-$color" : ''); ?>">
  <path fill-rule="evenodd" d="M12.53 16.28a.75.75 0 01-1.06 0l-7.5-7.5a.75.75 0 011.06-1.06L12 14.69l6.97-6.97a.75.75 0 111.06 1.06l-7.5 7.5z" clip-rule="evenodd"/>
</svg>
<?php /**PATH /var/www/vendor/moonshine/moonshine/src/Providers/../../resources/views/ui/icons/heroicons/chevron-down.blade.php ENDPATH**/ ?>