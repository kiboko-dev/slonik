<div class="heading">
    <<?php echo e($element->getTag()); ?> <?php echo e($attributes); ?>>
        <?php echo e($element->label()); ?>

    </<?php echo e($element->getTag()); ?>>
</div>
<?php /**PATH /var/www/vendor/moonshine/moonshine/src/Providers/../../resources/views/decorations/heading.blade.php ENDPATH**/ ?>