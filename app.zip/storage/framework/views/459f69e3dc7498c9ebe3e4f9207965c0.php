<div <?php echo e($attributes->merge(['class' => 'grid grid-cols-12 gap-6'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /var/www/vendor/moonshine/moonshine/src/Providers/../../resources/views/components/grid.blade.php ENDPATH**/ ?>