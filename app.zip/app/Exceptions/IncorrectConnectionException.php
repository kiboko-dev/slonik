<?php

namespace App\Exceptions;

use Exception;

class IncorrectConnectionException extends Exception
{
    //
}
